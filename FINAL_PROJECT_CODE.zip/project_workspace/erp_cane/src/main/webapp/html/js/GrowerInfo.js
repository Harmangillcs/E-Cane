
function registration()
{

    var name= document.getElementById("t1").value;
    var fthn= document.getElementById("t2").value;
    var dob= document.getElementById("t3").value;
    var Ad= document.getElementById("t4").value;

    
    //email id expression code
    var letters = /^[A-Za-z]+$/;
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if(name=='')
    {
        alert('Please enter your name');
    }
    else if(!letters.test(name))
    {
        alert('Name field required only alphabet characters');
    }
    else if(fthn=='')
    {
        alert('Please enter your Father Name');
    }
   
    else if(dob=='')
    {
        alert('Please enter Date of Birth.');
    }
    else if(Ad=='')
    {
        alert('Please enter Address.');
    }
    
    else
    {				                            
           alert('Your Account is created');
           // Redirecting to other page or webste code. 
           window.location = "http://www.campuslife.co.in"; 
    }
}
function clearFunc()
{
    document.getElementById("t1").value="";
    document.getElementById("t2").value="";
    document.getElementById("t3").value="";
    document.getElementById("t4").value="";
    
}