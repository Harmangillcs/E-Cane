function login()
	{
		var db = document.getElementById("dob").value;
		var adh = document.getElementById("aadharNo").value;
		var eml = document.getElementById("emailId").value;
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if(db =='')
		{
			alert("please enter date of birth.");
		}
		else if(adh=='')
		{
        	alert("enter the password");
		}
		else if(eml=='')
		{
        	alert("enter the password");
		}
		else if(!filter.test(eml))
		{
			alert("Enter valid email id.");
		}
		
		else
		{
	alert('Thank You for Your response ');
  //Redirecting to other page or webste code or you can set your own html page.
       window.location = "https://enquiry.caneup.in/";
			}
	}
	//Reset Inputfield code.
	
	function resetField()
	{
		document.getElementById("dob").value="";
		document.getElementById("aadharNo").value="";
		document.getElementById("emailId").value="";

		
	}