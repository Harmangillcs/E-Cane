function login()
	{
		var uname1 = document.getElementById("canVar1").value;

		
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		
        
		if(uname1 =='CaneType')
		{
			alert("please enter Cane Variety");

		}
		
		
		
		else
		{
	alert('Thank You your data is saved');
  //Redirecting to other page or webste code or you can set your own html page.
       window.location = "https://www.campuslife.co.in";
			}
	}
	//Reset Inputfield code.
	function resetField()
	{
		document.getElementById("canVar1").selectedIndex = 0;
		/*var dropdown = document.getElementById("canVar1")*/	

	}