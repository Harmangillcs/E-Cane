function login()
	{
		var uname = document.getElementById("canVar").value;
        var cd = document.getElementById("code").value;
		
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		
        if(cd =='')
		{
			alert("please enter code.");
		}
		if(uname =='Cane Variety')
		{
			alert("please enter Cane Type");
		}
		
		else if(!filter.test(cd))
		{
			alert("Enter valid Code.");
		}
		
		else
		{
	alert('Thank You your data is saved');
  //Redirecting to other page or webste code or you can set your own html page.
       window.location = "https://www.campuslife.co.in";
			}
	}
	//Reset Inputfield code.
	function resetField()
	{
        document.getElementById("code").value="";
		document.getElementById("canVar").selectedIndex = 0;
		

	}