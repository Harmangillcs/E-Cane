function registeration() {
	var uname = document.getElementById("UName").value;
	var fname = document.getElementById("FName").value;
	var address = document.getElementById("Address").value;
	var dob = document.getElementById("DOB").value;
	var email = document.getElementById("Email").value;
	var phone_no = document.getElementById("PNO").value;
	var aadhar = document.getElementById("Aadhar").value;
	var pass = document.getElementById("pass").value;
	var form = document.getElementById("registrationForm");

	// Validation checks go here...

	if (uname == '') {
		alert('Please enter your name');
	}
	else if (!/^[A-Za-z]+$/.test(uname)) {
		alert('User name field required only alphabet characters');
	}
	else if (fname == '') {
		alert('Please enter your Father name');
	}
	else if (!/^[A-Za-z]+$/.test(fname)) {
		alert('Father name field required only alphabet characters');
	}
	else if (address == '') {
		alert('Please enter your Address here');
	}
	else if (dob == '') {
		alert('Enter Date of birth here');
	}
	else if (email == '') {
		alert('Please enter your user email id');
	}
	else if (!/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(email)) {
		alert('Invalid email');
	}
	else if (phone_no == '') {
		alert('Please enter Phone no. here');
	}
	else if (!/^[0-9]+$/.test(phone_no)) {
		alert('Please enter a valid Phone no.');
	}
	else if (aadhar == '') {
		alert('Please enter your Aadhar Number here');
	}
	else if ( aadhar.length-1 == 12) {
		alert('Aadhar length should be of 12 numbers');
	}
	else if (!/^[0-9]+$/.test(aadhar)) {
		alert('Please enter a valid Aadhar Number');
	}
	else if (pass == '') {
		alert('Please enter your Password here');
	}
	else if ('!/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]'.test(pass)) {
		alert('Upper case, Lower case, Special character, and Numeric letter are required in the Password field');
	}
	else if (pass.length < 6 || pass.length > 12) {
		alert('Password length should be between 6 and 12 characters');
	}else{
		//action="/registered"
		form.action("../registered");
	}
}

function resetField() {
	document.getElementById("UName").value = "";
	document.getElementById("FName").value = "";
	document.getElementById("Address").value = "";
	document.getElementById("DOB").value = "";
	document.getElementById("Email").value = "";
	document.getElementById("PNO").value = "";
	document.getElementById("Aadhar").value = "";
	document.getElementById("pass").value = "";
}

function showPassword() {
  var x = document.getElementById("pass");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
