
function registration()
{

    //var name= document.getElementById("t1").value;
    var c1= document.getElementById("t1").value;
    var c2= document.getElementById("t2").value;
    var dob= document.getElementById("t3").value;
    var c4= document.getElementById("t4").value;
    var c5= document.getElementById("t5").value;
    var c6= document.getElementById("t6").value;
    var c7= document.getElementById("t7").value;
    var c8= document.getElementById("t8").value;
    var c9= document.getElementById("t9").value;
    var c10= document.getElementById("t10").value;

    
    //email id expression code
    var letters = /^[A-Za-z]+$/;
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if(c1=='')
    {
        alert('Please enter your name');
    }
    else if(!letters.test(c1))
    {
        alert('Name field required only alphabet characters');
    }
    else if(c2=='')
    {
        alert('Please enter data');
    }
    else if(c4=='')
    {
        alert('Please enter data');
    }
    else if(c5=='')
    {
        alert('Please enter data');
    }
    else if(c6=='')
    {
        alert('Please enter data');
    }
    else if(c7=='')
    {
        alert('Please enter data');
    }
    else if(c8=='')
    {
        alert('Please enter data');
    }
    else if(c9=='')
    {
        alert('Please enter data');
    }
    else if(c10=='')
    {
        alert('Please enter data');
    }
   
    else if(dob=='')
    {
        alert('Please enter Date of Birth.');
    }
    
    
    else
    {				                            
           alert('Your Account is created');
           // Redirecting to other page or webste code. 
           window.location = "http://www.campuslife.co.in"; 
    }
}
function clearFunc()
{
    document.getElementById("t1").value="";
    document.getElementById("t2").value="";
    document.getElementById("t3").value="";
    document.getElementById("t4").value="";
    document.getElementById("t5").value="";
    document.getElementById("t6").value="";
    document.getElementById("t7").value="";
    document.getElementById("t8").value="";
    document.getElementById("t9").value="";
    document.getElementById("t10").value="";
    
}