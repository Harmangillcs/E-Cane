function login()
	{
		var uname = document.getElementById("name").value;
        var cd = document.getElementById("code").value;
		
		//var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        var filter = /^[a-zA-Z0-9]+$/;
		
        if(cd =='')
		{
			alert("please enter id.");
		}
		if(uname =='Country Name')
		{
			alert("please enter city Name");
		}
		
		else if(!filter.test(cd))
		{
			alert("Enter valid id.");
		}
		
		else
		{
	alert('Thank You your data is saved');
  //Redirecting to other page or webste code or you can set your own html page.
       window.location = "https://www.campuslife.co.in";
			}
	}
	//Reset Inputfield code.
	function resetField()
	{
        document.getElementById("name").value="";
		document.getElementById("code").value="";
		

	}