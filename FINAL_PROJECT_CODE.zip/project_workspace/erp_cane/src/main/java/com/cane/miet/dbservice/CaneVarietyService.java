package com.cane.miet.dbservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cane.miet.constant.MyConstants;
import com.cane.miet.dao.CaneVarietyDao;
import com.cane.miet.dbcon.MyDbConection;

public class CaneVarietyService {
	public int save(CaneVarietyDao cvdao) {
		Connection con = MyDbConection.getConnection();
		int i =0;
		String qry = "insert into "+MyConstants.CANE_VARIETY_MASTER_TABLE+"(name) values('"+cvdao.getName()
		+"');";
		System.out.println("sql query--->"+qry);
		try {
			Statement stmt = con.createStatement();
			 i = stmt.executeUpdate(qry);			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;		
	}
	public int update(CaneVarietyDao cvdao) {
		Connection con = MyDbConection.getConnection();
		int i =0;
		String qry = "update "+MyConstants.CANE_VARIETY_MASTER_TABLE+" set name='"+cvdao.getName()
		+"' where id="+cvdao.getId()+";";
		System.out.println("sql query--->"+qry);
		try {
			Statement stmt = con.createStatement();
			 i = stmt.executeUpdate(qry);			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}
	
	public List<CaneVarietyDao> getCaneVarietyList() {
		Connection con = MyDbConection.getConnection();
		List<CaneVarietyDao> lstCC = new ArrayList<CaneVarietyDao>();
		String qry = "select * from "+MyConstants.CANE_VARIETY_MASTER_TABLE;
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 CaneVarietyDao cd = new CaneVarietyDao();
				 cd.setId(rs.getInt("id"));
				 cd.setName(rs.getString("name"));
				 lstCC.add(cd);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstCC;
	}
	
	
}
