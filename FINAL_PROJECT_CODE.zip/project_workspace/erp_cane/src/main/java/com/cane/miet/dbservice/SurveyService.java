package com.cane.miet.dbservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cane.miet.constant.MyConstants;
import com.cane.miet.dao.GrowerDao;
import com.cane.miet.dao.SurveyDao;
import com.cane.miet.dbcon.MyDbConection;

public class SurveyService {
	
	public int save(SurveyDao sdao) {
		Connection con = MyDbConection.getConnection();
		int i =0;
		String qry = "insert into "+MyConstants.CANE_SURVEY_TABLE+"(cane_variety_id,cane_category_id,session_id,grower_id,area) values("
				+sdao.getCaneVarityId()+","+sdao.getCaneCategoryId()+", "+sdao.getSessionId()+", "+sdao.getGrowerId()+", "+sdao.getArea()+");";
		System.out.println("sql query--->"+qry);
		try {
			Statement stmt = con.createStatement();
			 i = stmt.executeUpdate(qry);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}
	
	/*public List<GrowerDao> getGrowerList() {
		Connection con = MyDbConection.getConnection();
		 List<GrowerDao> gdList = new ArrayList<>();
//		int i =0; yaha change kiya
		String qry = "select * from "+MyConstants.GROWER_MASTER_TABLE+";";
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 GrowerDao cd = new GrowerDao();
				 cd.setId(rs.getInt("id"));
				 cd.setFirstName(rs.getString("first_name"));
				 cd.setLastName(rs.getString("last_name"));
				 cd.setFatherName(rs.getString("father_name"));
				 cd.setMotherName(rs.getString("mother_name"));
				 cd.setAddress(rs.getString("address"));
				 cd.setVillageId(rs.getInt("village_id"));
				 cd.setPhoneNo(rs.getString("phone_no"));
				 cd.setAddharNo(rs.getString("aadhar_no"));
				 cd.setPinCode(rs.getString("pincode"));
				 cd.setDob(rs.getString("dob"));
				 
				 gdList.add(cd);
			 }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return gdList;
		
	}*/

}