package com.cane.miet.dbservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cane.miet.constant.MyConstants;
import com.cane.miet.dao.UserRegistrationDao;
import com.cane.miet.dbcon.MyDbConection;

public class RegistrationService {
	
	public int registerUser(UserRegistrationDao udao) {
		Connection con = MyDbConection.getConnection();
		int i =0;
		String qry = "insert into "+MyConstants.USER_INFO_TABLE+"(user_name,father_name,address,email"
				+ ",phone_no,Aadhar_No,password,dob) values('"+udao.getUserName()+"','"+udao.getFatherName()
				+"', '"+udao.getAddress()+"', '"+udao.getEmail()+"', '"+udao.getPhoneNo()+"','"+udao.getAddharNo()
				+"', '"+udao.getPassword()+"', '"+udao.getDob()+"');";
		System.out.println("sql query--->"+qry);
		try {
			Statement stmt = con.createStatement();
			 i = stmt.executeUpdate(qry);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}
	
	public UserRegistrationDao loginUser(UserRegistrationDao udao) {
		Connection con = MyDbConection.getConnection();
		UserRegistrationDao cd = null;
//		int i =0; yaha change kiya
		String qry = "select * from "+MyConstants.USER_INFO_TABLE+" where user_name='"+udao.getUserName()
		+"' or email='"+udao.getUserName()+"' or phone_no='"+udao.getUserName()
		+"' and Password='"+udao.getPassword()+"';";
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 cd = new UserRegistrationDao();
				 cd.setId(rs.getInt("user_id"));
				 cd.setUserName(rs.getString("user_name"));
				 cd.setUserName(rs.getString("user_name"));
				 cd.setFatherName(rs.getString("father_name"));
				 cd.setAddress(rs.getString("Address"));
				 cd.setEmail(rs.getString("Email"));
				 cd.setPhoneNo(rs.getString("Phone_no"));
				 cd.setAddharNo(rs.getString("Aadhar_No"));
				 cd.setDob(rs.getString("dob"));
				 
				 //lstCC.add(cd);
			 }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cd;
		
	}
	
	public UserRegistrationDao userNamePassword(UserRegistrationDao udao) {
		Connection con = MyDbConection.getConnection();
		UserRegistrationDao cd = null;
//		int i =0; yaha change kiya
		String qry = "select * from "+MyConstants.USER_INFO_TABLE+" where dob='"+udao.getDob()
		+"' or Email='"+udao.getEmail()+"' or Aadhar_No='"+udao.getAddharNo()+"';";
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 cd = new UserRegistrationDao();
				 cd.setUserName(rs.getString("user_name"));
				 cd.setPassword(rs.getString("Password"));
				 
				 
				 //lstCC.add(cd);
			 }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cd;
		
	}

}