package com.cane.miet.dao;

public class StateDao {
	
	private String name;
	private String code;
	private int id;
	private int countryId;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCountryId() {
		return countryId;
	}
	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}
	@Override
	public String toString() {
		return "StateDao [name=" + name + ", code=" + code + ", id=" + id + ", countryId=" + countryId + "]";
	}
	
	
	
	

}
