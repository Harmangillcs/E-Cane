package com.cane.miet.dbservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cane.miet.constant.MyConstants;
import com.cane.miet.dao.CityDao;
import com.cane.miet.dbcon.MyDbConection;

public class CityService {
	public int save(CityDao cdao) {
		Connection con = MyDbConection.getConnection();
		int i =0;
		String qry = "insert into "+MyConstants.CITY_MASTER_TABLE+"(name,state_id) values('"+cdao.getName()
		+"','"+cdao.getStateId()+"');";
		System.out.println("sql query--->"+qry);
		try {
			Statement stmt = con.createStatement();
			 i = stmt.executeUpdate(qry);			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}
	
	public List<CityDao> getCityList() {
		Connection con = MyDbConection.getConnection();
		List<CityDao> lstState = new ArrayList<CityDao>();
		String qry = "select * from "+MyConstants.CITY_MASTER_TABLE;
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 CityDao cd = new CityDao();
				 cd.setName(rs.getString("name"));
				 cd.setId(rs.getInt("id"));
				 cd.setStateId(rs.getInt("state_id"));
				 lstState.add(cd);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstState;
	}
	
	public List<CityDao> getCityListByStateId(int stateId) {
		Connection con = MyDbConection.getConnection();
		List<CityDao> lstCity = new ArrayList<CityDao>();
		String qry = "select * from "+MyConstants.CITY_MASTER_TABLE
				+" where state_id="+ stateId;
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 CityDao cd = new CityDao();
				 cd.setName(rs.getString("name"));
				 cd.setId(rs.getInt("id"));
				 cd.setStateId(rs.getInt("state_id"));
				 lstCity.add(cd);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstCity;
	}
}
