package com.cane.miet.dbservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cane.miet.constant.MyConstants;
import com.cane.miet.dao.CountryDao;
import com.cane.miet.dbcon.MyDbConection;

public class CountryService {
	public int save(CountryDao cdao) {
		Connection con = MyDbConection.getConnection();
		int i =0;
		String qry = "insert into "+MyConstants.COUNTRY_MASTER_TABLE+"(name,code) values('"+cdao.getName()
		+"','"+cdao.getCode()+"');";
		System.out.println("sql query--->"+qry);
		try {
			Statement stmt = con.createStatement();
			 i = stmt.executeUpdate(qry);			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}
	
	public List<CountryDao> getCountryList() {
		Connection con = MyDbConection.getConnection();
		List<CountryDao> lstCountry = new ArrayList<CountryDao>();
		String qry = "select * from "+MyConstants.COUNTRY_MASTER_TABLE;
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 CountryDao cd = new CountryDao();
				 cd.setId(rs.getInt("id"));
				 cd.setCode(rs.getString("code"));
				 cd.setName(rs.getString("name"));
				 lstCountry.add(cd);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstCountry;
	}
	
	public List<CountryDao> getStateList() {
		Connection con = MyDbConection.getConnection();
		List<CountryDao> lstCountry = new ArrayList<CountryDao>();
		String qry = "select * from "+MyConstants.COUNTRY_MASTER_TABLE;
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 CountryDao cd = new CountryDao();
				 cd.setId(rs.getInt("id"));
				 cd.setCode(rs.getString("code"));
				 cd.setName(rs.getString("name"));
				 lstCountry.add(cd);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstCountry;
	}
	
	/*public List<CountryDao> getCountryStateList() {
		Connection con = MyDbConection.getConnection();
		Map<Integer, Map<CountryDao, Map<Integer, List<StateDao>>>> cntStatMap = new HashMap<>();
		List<CountryDao> lstCountry = new ArrayList<CountryDao>();
		String qry = "select cm.id cnt_id, cm.name cnt_name, sm.id stat_id, sm.name stat_name from "+MyConstants.COUNTRY_MASTER_TABLE+
				"cm inner join "+ MyConstants.STATE_MASTER_TABLE+
				" sm on cm.id = sm.country_id;";
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 Integer cntId = rs.getInt("cnt_id");
				 List<StateDao> lstStatDao= null;// = new ArrayList<>();
				 Map<CountryDao, Map<Integer, List<StateDao>>> mpCntStat = (Map)cntStatMap.get(cntId);
				 CountryDao cd = null;
				 if(mpCntStat == null) {
					 mpCntStat = new HashMap<>();
					 lstStatDao = new ArrayList<>();
				 }else {
					 cd.setId(rs.getInt("cnt_id"));
					 cd.setName(rs.getString("cnt_name"));
					 lstStatDao = mpCntStat.get(cd);
				 }
				 
				 
				 cntStatMap.put(cntId, cd);
				 //lstCountry.add(cd);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstCountry;
	}*/
}
