package com.cane.miet.dao;

public class CaneRateDao {
	
	private float rate;
	private int id;
	private int categoryId;
	private int varietyId;
	private int sessionId;
	
	public float getRate() {
		return rate;
	}
	public void setRate(float rate) {
		this.rate = rate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int getVarietyId() {
		return varietyId;
	}
	public void setVarietyId(int varietyId) {
		this.varietyId = varietyId;
	}
	public int getSessionId() {
		return sessionId;
	}
	public void setSessionId(int sessionId) {
		this.sessionId = sessionId;
	}
	
	@Override
	public String toString() {
		return "CaneRateDao [rate=" + rate + ", id=" + id + ", categoryId=" + categoryId + ", varietyId=" + varietyId
				+ ", sessionId=" + sessionId + "]";
	}
	

}
