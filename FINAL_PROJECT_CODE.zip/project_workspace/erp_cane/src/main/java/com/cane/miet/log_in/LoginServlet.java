package com.cane.miet.log_in;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cane.miet.dbcon.MyDbConection;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        System.out.println("LoginServlet.LoginServlet()");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("LoginServlet.doGet()");
		long start = System.currentTimeMillis();
		System.out.println("LoginServlet.doGet()");
		MyDbConection.getConnection();
		long end = System.currentTimeMillis();
		System.out.println("total time taken in milis="+(end-start));
		response.getWriter().append("Served at: ").append(request.getContextPath());
//		RequestDispatcher rd = request.getRequestDispatcher("./html/login.html"); 
		RequestDispatcher rd = request.getRequestDispatcher("./index_1.html");
		rd.forward(request, response);
	}



}
