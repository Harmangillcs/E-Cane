package com.cane.miet.servlet.survey;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cane.miet.dao.CaneRateDao;
import com.cane.miet.dao.SurveyDao;
import com.cane.miet.dbservice.CaneRateService;
import com.cane.miet.dbservice.SurveyService;

/**
 * Servlet implementation class SurveyEntry
 */
@WebServlet("/survey")
public class SurveyEntry extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SurveyEntry() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int variteyId = Integer.parseInt(request.getParameter("caneVarietyId"));
		int categoryId = Integer.parseInt(request.getParameter("caneCategoryId"));
		int sessionId = Integer.parseInt(request.getParameter("sessionId"));
		int growerId = Integer.parseInt(request.getParameter("growerid"));
		double area = Double.parseDouble(request.getParameter("area"));
		SurveyDao sd = new SurveyDao();
		sd.setArea(area);
		sd.setSessionId(sessionId);
		sd.setCaneVarityId(variteyId);
		sd.setCaneCategoryId(categoryId);
		sd.setGrowerId(growerId);
		System.out.println(sd);
		
		SurveyService crs = new SurveyService();
		crs.save(sd);
		response.sendRedirect("index_1.html");
	}

}
