package com.cane.miet.constant;

public class MyConstants {
	
	   public static final String con_url="jdbc:mysql://localhost/";
	   public static final String db_name="cane_erp";
	   public static final String user= "root";
	   public static final String pass= "root";
	   
	   public static final String USER_INFO_TABLE = "user_info";
	   public static final String SESSION_MASTER_TABLE = "session_master";
	   public static final String COUNTRY_MASTER_TABLE = "country_master";
	   public static final String STATE_MASTER_TABLE = "state_master";
	   public static final String CITY_MASTER_TABLE = "city_master";
	   public static final String VILLAGE_MASTER_TABLE = "village_master";
	   public static final String CANE_CATEGORY_MASTER_TABLE = "cane_category_master";
	   public static final String CANE_RATE_MASTER_TABLE = "cane_rate_master";
	   public static final String CANE_VARIETY_MASTER_TABLE = "cane_variety_master";
	   public static final String GROWER_MASTER_TABLE = "grower_master";
	   public static final String CANE_SURVEY_TABLE = "cane_survey";
}
