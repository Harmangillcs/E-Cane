package com.cane.miet.servlet.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cane.miet.dao.UserRegistrationDao;
import com.cane.miet.dbservice.RegistrationService;

/**
 * Servlet implementation class UserLogin
 */
@WebServlet("/userlogin")
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email = request.getParameter("useremail");
		System.out.println("email-->"+ email);
		String pwd = request.getParameter("pwd");
		UserRegistrationDao urd = new UserRegistrationDao();
		urd.setUserName(email);
		urd.setPassword(pwd);
		RegistrationService rs = new RegistrationService();
		urd = rs.loginUser(urd);
		RequestDispatcher rd = null;
		if(urd != null) {
			rd = request.getRequestDispatcher("index_1.html");
			request.setAttribute("userDao", urd);
			rd.forward(request, response);
		}else {
			//response.sendRedirect("./html/login.html");
			response.sendRedirect("./html/login.html");
		}		
		
	}

}
