package com.cane.miet.dao;

public class SurveyDao {
	
	int id;
	int caneVarityId;
	int caneCategoryId;
	double area;
	int sessionId;
	int growerId;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCaneVarityId() {
		return caneVarityId;
	}
	public void setCaneVarityId(int caneVarityId) {
		this.caneVarityId = caneVarityId;
	}
	public int getCaneCategoryId() {
		return caneCategoryId;
	}
	public void setCaneCategoryId(int caneCategoryId) {
		this.caneCategoryId = caneCategoryId;
	}
	public double getArea() {
		return area;
	}
	public void setArea(double area) {
		this.area = area;
	}
	public int getSessionId() {
		return sessionId;
	}
	public void setSessionId(int sessionId) {
		this.sessionId = sessionId;
	}
	public int getGrowerId() {
		return growerId;
	}
	public void setGrowerId(int growerId) {
		this.growerId = growerId;
	}
	@Override
	public String toString() {
		return "SurveyDao [id=" + id + ", caneVarityId=" + caneVarityId + ", caneCategoryId=" + caneCategoryId + ", area="
				+ area + ", sessionId=" + sessionId + ", growerId=" + growerId + "]";
	}
	
	
	

}
