package com.cane.miet.dao;

public class GrowerDao {
	
	private String firstName;
	private String lastName;
	private String fatherName;
	private String motherName;
	private String address;
	private String dob;
	private String phoneNo;
	private String addharNo;
	private String pinCode;
	
	private int id;	
	private int villageId;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddharNo() {
		return addharNo;
	}
	public void setAddharNo(String addharNo) {
		this.addharNo = addharNo;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getVillageId() {
		return villageId;
	}
	public void setVillageId(int villageId) {
		this.villageId = villageId;
	}
	@Override
	public String toString() {
		return "GrowerDao [firstName=" + firstName + ", lastName=" + lastName + ", fatherName=" + fatherName
				+ ", motherName=" + motherName + ", address=" + address + ", dob=" + dob + ", phoneNo=" + phoneNo
				+ ", addharNo=" + addharNo + ", pinCode=" + pinCode + ", id=" + id + ", villageId=" + villageId + "]";
	}
}
