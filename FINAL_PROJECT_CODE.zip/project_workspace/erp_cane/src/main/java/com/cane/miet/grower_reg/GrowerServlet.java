package com.cane.miet.grower_reg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GrowerServlet
 */
@WebServlet("/grower")
public class GrowerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String INSERT_QUERY="INSERT INTO USER(Name,Father Name,Date of Birth,Address) VALUES(?,?,?,?)";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GrowerServlet() {
        super();
        // TODO Auto-generated constructor stub
        System.out.println("GrowerServlet.GrowerServlet()");
    }

    protected void doGet(HttpServletRequest req,HttpServletResponse res) {
		PrintWriter pw = null;
		try {
			pw = res.getWriter();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		res.setContentType("html/text");
		String Name=req.getParameter("Enter Name :");
		String Father_Name=req.getParameter("Enter Father Name :");
		String dob=req.getParameter("Enter Date of Birth :");
		String Address=req.getParameter("Enter Address :");
		
		System.out.println("Name"+Name);
		System.out.println("Father Name"+Father_Name);
		System.out.println("Date of Birth"+dob);
		System.out.println("Address"+Address);
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		try(Connection con=DriverManager.getConnection("jdbc:mysql:///cane_erp","root","root");
				PreparedStatement ps=con.prepareStatement(INSERT_QUERY);){
			ps.setString(1, Name);
			ps.setString(2,Father_Name);
			ps.setString(3, dob);
			ps.setString(4, Address);
			
			int count=ps.executeUpdate();
			if(count==0) {
				pw.println("record not submitted");
			}
			else {
				pw.println("record  submitted");
			}
			}
		catch(SQLException se) {
			pw.println(se.getMessage());
			se.printStackTrace();
		}
		catch(Exception e) {
			pw.println(e.getMessage());
			e.printStackTrace();
		}finally {
	        if (pw != null) {
		pw.close();
	        }
		}
    }
}
