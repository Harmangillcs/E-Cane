package com.cane.miet.dbcon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cane.miet.constant.MyConstants;

public class MyDbConection {
	private static Connection con;

	public static Connection getConnection() {
		if (con == null)
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(MyConstants.con_url + MyConstants.db_name, MyConstants.user,
						MyConstants.pass);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO: handle exception
				e.printStackTrace();
			}

		return con;

	}

}
