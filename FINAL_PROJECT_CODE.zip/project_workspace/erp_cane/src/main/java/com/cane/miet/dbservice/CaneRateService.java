package com.cane.miet.dbservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cane.miet.constant.MyConstants;
import com.cane.miet.dao.CaneRateDao;
import com.cane.miet.dbcon.MyDbConection;

public class CaneRateService {
	public int save(CaneRateDao crdao) {
		Connection con = MyDbConection.getConnection();
		int i =0;
		String qry = "insert into "+MyConstants.CANE_RATE_MASTER_TABLE+"(category_id, varity_id, rate, session_id) values("+crdao.getCategoryId()
		+","+crdao.getVarietyId()+","+crdao.getRate()+","+crdao.getSessionId()+");";
		System.out.println("sql query--->"+qry);
		try {
			Statement stmt = con.createStatement();
			 i = stmt.executeUpdate(qry);			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;		
	}
	
	
	public List<CaneRateDao> getCaneRateList() {
		Connection con = MyDbConection.getConnection();
		List<CaneRateDao> lstCC = new ArrayList<CaneRateDao>();
		String qry = "select * from "+MyConstants.CANE_RATE_MASTER_TABLE;
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 CaneRateDao cd = new CaneRateDao();
				 cd.setId(rs.getInt("id"));
				 cd.setCategoryId(rs.getInt("category_id"));
				 cd.setVarietyId(rs.getInt("varity_id"));
				 cd.setSessionId(rs.getInt("session_id"));
				 cd.setRate(rs.getFloat("rate"));				 
				 lstCC.add(cd);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstCC;
	}
	
	
}
