package com.cane.miet.dao;

public class SessionMasterDao {
	
	private String name;
	private int id;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "SessionMasterDao [name=" + name + ", id=" + id + "]";
	}
}
