package com.cane.miet.dbservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cane.miet.constant.MyConstants;
import com.cane.miet.dao.CaneCategoryDao;
import com.cane.miet.dbcon.MyDbConection;

public class CaneCategoryService {
	public int save(CaneCategoryDao cdao) {
		Connection con = MyDbConection.getConnection();
		int i =0;
		String qry = "insert into "+MyConstants.CANE_CATEGORY_MASTER_TABLE+"(name) values('"+cdao.getName()
		+"');";
		System.out.println("sql query--->"+qry);
		try {
			Statement stmt = con.createStatement();
			 i = stmt.executeUpdate(qry);			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;		
	}
	public int update(CaneCategoryDao ccdao) {
		Connection con = MyDbConection.getConnection();
		int i =0;
		String qry = "update "+MyConstants.CANE_CATEGORY_MASTER_TABLE+" set name='"+ccdao.getName()
		+"' where id="+ccdao.getId()+";";
		System.out.println("sql query--->"+qry);
		try {
			Statement stmt = con.createStatement();
			 i = stmt.executeUpdate(qry);			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}
	
	public List<CaneCategoryDao> getCaneCategoryList() {
		Connection con = MyDbConection.getConnection();
		List<CaneCategoryDao> lstCC = new ArrayList<CaneCategoryDao>();
		String qry = "select * from "+MyConstants.CANE_CATEGORY_MASTER_TABLE;
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 CaneCategoryDao cd = new CaneCategoryDao();
				 cd.setId(rs.getInt("id"));
				 cd.setName(rs.getString("name"));
				 lstCC.add(cd);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstCC;
	}
	
	
}
