package com.cane.miet.servlet.master;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cane.miet.dao.CityDao;
import com.cane.miet.dbservice.CityService;

/**
 * Servlet implementation class CityServlet
 */
@WebServlet("/city")
public class CityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CityServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println("state id-->"+request.getParameter("stateId"));
		System.out.println("state name-->"+request.getParameter("state"));
		int sId = Integer.parseInt(request.getParameter("state"));
		String name = request.getParameter("name");
		CityDao cdao = new CityDao();
		cdao.setName(name);
		cdao.setStateId(sId);
		System.out.println(cdao);
		CityService ss = new CityService();
		ss.save(cdao);
		response.sendRedirect("index_1.html");
	}

}
