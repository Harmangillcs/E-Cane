package com.cane.miet.registration;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cane.miet.dao.GrowerDao;
import com.cane.miet.dbservice.GrowerService;

/**
 * Servlet implementation class GrowerRegistrationServlet
 */
@WebServlet("/grower_registration")
public class GrowerRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GrowerRegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName = (String) request.getParameter("firstName");
		String lastName = (String) request.getParameter("lastName");
		String fatherName = (String) request.getParameter("fatherName");
		String motherName = (String) request.getParameter("motherName");
		
		String address = (String) request.getParameter("address");
		String dob = (String) request.getParameter("dob");
		String phoneNo = request.getParameter("phoneNo").trim();
		String addharNo = request.getParameter("aadharNo").trim();
		int villageId = Integer.parseInt(request.getParameter("cityName").trim());
		String pinCode = request.getParameter("pinCode").trim();
		
		GrowerDao gdao = new GrowerDao();
		gdao.setFirstName(firstName);
		gdao.setLastName(lastName);
		gdao.setFatherName(fatherName);
		gdao.setMotherName(motherName);
		gdao.setAddress(address);
		gdao.setDob(dob);
		gdao.setPhoneNo(phoneNo);
		gdao.setAddharNo(addharNo);
		gdao.setVillageId(villageId);
		gdao.setPinCode(pinCode);
		System.out.println("grower info-->"+ gdao);
		GrowerService gs = new GrowerService();
		gs.registerGrower(gdao);
		response.sendRedirect("index_1.html");
	}

}
