package com.cane.miet.dao;

import java.io.Serializable;

public class UserRegistrationDao implements Serializable {
	
	private static final long serialVersionUID = 1L;//yaha new update kiya
	private String userName;
	private String fatherName ;
	private String address ;
	private String dob ;
	private String email ;
	private String phoneNo ;
	private String addharNo;
	private String password ;
	private int id;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddharNo() {
		return addharNo;
	}
	public void setAddharNo(String addharNo) {
		this.addharNo = addharNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "UserRegistrationDao [userName=" + userName + ", fatherName=" + fatherName + ", address=" + address
				+ ", dob=" + dob + ", email=" + email + ", phoneNo=" + phoneNo + ", addharNo=" + addharNo
				+ ", password=" + password + ", id=" + id + "]";
	}
	
	

}
