package com.cane.miet.dbservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cane.miet.constant.MyConstants;
import com.cane.miet.dao.StateDao;
import com.cane.miet.dbcon.MyDbConection;

public class StateService {
	public int save(StateDao sdao) {
		Connection con = MyDbConection.getConnection();
		int i =0;
		String qry = "insert into "+MyConstants.STATE_MASTER_TABLE+"(name,code,country_id) values('"+sdao.getName()
		+"','"+sdao.getCode()+"',"+sdao.getCountryId()+");";
		System.out.println("sql query--->"+qry);
		try {
			Statement stmt = con.createStatement();
			 i = stmt.executeUpdate(qry);			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}
	
	public List<StateDao> getStateList() {
		Connection con = MyDbConection.getConnection();
		List<StateDao> lstState = new ArrayList<StateDao>();
		String qry = "select * from "+MyConstants.STATE_MASTER_TABLE;
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 StateDao cd = new StateDao();
				 cd.setCode(rs.getString("code"));
				 cd.setName(rs.getString("name"));
				 cd.setId(rs.getInt("id"));
				 cd.setCountryId(rs.getInt("country_id"));
				 lstState.add(cd);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstState;
	}
	
	public List<StateDao> getStateListByCountryId(int countryId) {
		Connection con = MyDbConection.getConnection();
		List<StateDao> lstState = new ArrayList<StateDao>();
		String qry = "select * from "+MyConstants.STATE_MASTER_TABLE
				+" where country_id="+ countryId;
		System.out.println("sql query--->"+qry);
		try {
			PreparedStatement ps = con.prepareStatement(qry);
			 ResultSet rs = ps.executeQuery();
			 while(rs.next()) {
				 StateDao cd = new StateDao();
				 cd.setCode(rs.getString("code"));
				 cd.setName(rs.getString("name"));
				 cd.setId(rs.getInt("id"));
				 cd.setCountryId(rs.getInt("country_id"));
				 lstState.add(cd);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstState;
	}
}
