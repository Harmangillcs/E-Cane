package com.cane.miet.servlet.master;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cane.miet.dao.CaneRateDao;
import com.cane.miet.dbservice.CaneRateService;

/**
 * Servlet implementation class CaneRateMaster
 */
@WebServlet("/canerate")
public class CaneRateMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CaneRateMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int variteyId = Integer.parseInt(request.getParameter("canevariety"));
		int categoryId = Integer.parseInt(request.getParameter("canecategory"));
		int sessionId = Integer.parseInt(request.getParameter("session"));
		float rate = Float.parseFloat(request.getParameter("rateTxt"));
		
		CaneRateDao crdao = new CaneRateDao();
		crdao.setCategoryId(categoryId);
		crdao.setVarietyId(variteyId);
		crdao.setSessionId(sessionId);
		crdao.setRate(rate);
		CaneRateService crs = new CaneRateService();
		crs.save(crdao);
		response.sendRedirect("index_1.html");
	}

}
