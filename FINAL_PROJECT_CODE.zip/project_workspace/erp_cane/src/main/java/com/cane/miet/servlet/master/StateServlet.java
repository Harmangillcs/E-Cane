package com.cane.miet.servlet.master;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cane.miet.dao.StateDao;
import com.cane.miet.dbservice.StateService;

/**
 * Servlet implementation class StateServlet
 */
@WebServlet("/state")
public class StateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int cId = Integer.parseInt(request.getParameter("countryId"));
		String name = request.getParameter("name");
		String code = request.getParameter("code");
		StateDao sdao = new StateDao();
		sdao.setName(name);
		sdao.setCode(code);
		sdao.setCountryId(cId);
		System.out.println(sdao);
		StateService ss = new StateService();
		ss.save(sdao);
		response.sendRedirect("index_1.html");
	}

}
