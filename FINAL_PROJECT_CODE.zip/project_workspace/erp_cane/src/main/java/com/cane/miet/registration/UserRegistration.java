package com.cane.miet.registration;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cane.miet.dao.UserRegistrationDao;
import com.cane.miet.dbservice.RegistrationService;

/**
 * Servlet implementation class UserRegistration
 */
@WebServlet("/userRegistration")
public class UserRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserRegistration() {
        super();
        // TODO Auto-generated constructor stub
        System.out.println("UserRegistration.UserRegistration()");
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("request--->"+request.toString());
		System.out.println(request.getParameterNames().toString());
		Enumeration<String> enu = request.getAttributeNames();
		while(enu.hasMoreElements()) {
			System.out.println(enu.nextElement());
			
		}
		String userName = (String) request.getParameter("UName");
		System.out.println("name ="+ userName);
		String fatherName = (String) request.getParameter("FName");
		String address = (String) request.getParameter("Address");
		String dob = (String) request.getParameter("DOB");
		String email = (String) request.getParameter("Email");
		String phoneNo = (String) request.getParameter("PNO");
		String addharNo = (String) request.getParameter("Aadhar");
		String password = (String) request.getParameter("pass");
		
		
		UserRegistrationDao udao = new UserRegistrationDao();
		udao.setUserName(userName);
		udao.setFatherName(fatherName);
		udao.setAddress(address);
		udao.setDob(dob);
		udao.setEmail(email);
		udao.setPhoneNo(phoneNo);
		udao.setAddharNo(addharNo);
		udao.setPassword(password);
		System.out.println(udao.toString()); 
		RegistrationService rs = new RegistrationService();
//		int i =rs.registerUser(udao);
		int i =rs.registerUser(udao);
		
		System.out.println("user saved..."+i);
		RequestDispatcher rd = request.getRequestDispatcher("index_1.html");
		request.setAttribute("userDao", udao);
		rd.forward(request, response);
	}

}
