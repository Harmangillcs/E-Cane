package com.cane.miet.dao;

public class CityDao {
	
	private String name;
	private int id;
	private int stateId;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getStateId() {
		return stateId;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	@Override
	public String toString() {
		return "CityDao [name=" + name + ", id=" + id + ", stateId=" + stateId + "]";
	}
	
	

}
